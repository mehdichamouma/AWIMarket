<template>
  <div id="app2">
    <router-view class="view"></router-view>
  </div>
</template>
